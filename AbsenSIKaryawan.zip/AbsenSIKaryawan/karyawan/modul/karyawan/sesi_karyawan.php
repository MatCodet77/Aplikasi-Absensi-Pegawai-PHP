<?php 
if(empty($_SESSION['idsi']) AND empty($_SESSION['idsi'])){
	header('location:../login_karyawan.php');
}
 ?>